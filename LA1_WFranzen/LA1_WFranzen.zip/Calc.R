#William Franzen
#Problem 1

#1a
ans1a <- 10**2 + (3*162/8.5) - 3.0065
ans1a

#1b
ans1b <- 3**(2+abs(-5)) - 4 + 164**(-2**(2.25-log(3)))
ans1b

#1c
ans1c <- choose(8, 4) * 0.32**5 * 1.8**11
ans1c

#1d
ans1d <- 1.7 * exp(-0.9) / factorial(5) + 4
ans1d